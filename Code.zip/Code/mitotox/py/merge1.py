import pandas as pd
data=pd.read_csv('/home/users/lifei/MLx/mitox/running/Descriptor result/descriptor_all.csv')

data2=pd.read_csv('/home/users/lifei/MLx/mitox/running/Descriptor result/descriptor.csv')

s1=pd.DataFrame(data2['outcome'].tolist(),index=data2['name'],columns=['outcome'])
print(s1)
d= pd.concat([data, s1], axis=1)

d.to_csv('/home/users/lifei/MLx/mitox/running/Descriptor result/sample.csv')