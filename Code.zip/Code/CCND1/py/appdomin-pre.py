import pandas as pd
from sklearn.decomposition import PCA
from sklearn import preprocessing
import numpy as np
import pickle
def sim_tonimoto(user1, user2):
    common = []

    for item in range(len(user1)):
        if user1[item] != user2[item]:
            common.append(item)

    if len(common) == 0:
        return 0

    common_num = len(common)
    user1_num = len(user1)
    user2_num = len(user2)

    res = float(common_num) / (user1_num + user2_num - common_num)
    return res

def eucliDist(A, B):
 return np.sqrt(sum(np.power((A - B), 2)))
def ces(A, B):
    return np.power((A - B), 2)
def minmax(min,max):
    try:
        if max-min!=0:
            return lambda a : (a -min)/(max-min)
        else:
            return lambda a :a-a
    except:
        return lambda a: a - a
def appcalition():
    data3=pd.read_csv('../Descriptor result/pre_sample.csv',index_col=0)
    #data3.astype('float')
    
    data3.replace(['True', 'False'], [0, 1], inplace=True)
    col = list(data3.columns)
    data3[col] = data3[col].apply(pd.to_numeric, errors='coerce')
    data3.fillna(0, inplace=True)
    app=pd.read_csv('../appdomin/appdomin.csv',index_col=0)
    for i in range(len(app.columns)):
        data3[app.columns[i]]=data3[app.columns[i]].apply(minmax(app.iat[1, i],app.iat[0, i]))
    data3=data3[list(app.columns)]
    print(data3)
    
    distance = []
    for j in range(len(data3)):
        point = data3.iloc[j, :]
        euclidist = ces(np.array(app.iloc[2,:],dtype='float64'),point)
        euclidist.fillna(value=0, inplace=True)
        result=np.sqrt(sum(euclidist))
        distance.append(result)
    print(distance)
    print(data3.index)
    pd.DataFrame(distance).to_csv('../appdomin/pre_distance.csv')
appcalition()
