import pandas as pd
from PyFingerprint.fingerprint import  get_fingerprints
def colum(colum_name):
  f=open('../fingerprinter/'+colum_name+'.txt')
  name=[]
  for line in f:
    name.extend(line.split(','))
  return name
def fingprinter(data):
    fingertypes= ['pubchem']
    smlist = data['smile'].tolist()
    output = {}

    for f in fingertypes:
        output[f] = get_fingerprints(smlist, f)

    output_np = output.copy()
    df_empty=pd.DataFrame()
    for k, fps in output.items():
        output_np[k] = pd.DataFrame([fp.to_numpy() for fp in fps],columns=colum(k),index=data['name'])
        df_empty=pd.concat([df_empty,output_np[k]],axis=1)
    return df_empty
data=pd.read_csv('../Descriptor result/new.csv')
b=fingprinter(data)
b.to_csv('../Descriptor result/zhiwen-pubchem.csv')