import pandas as pd
from rdkit import Chem
from mordred import Calculator, descriptors
import numpy as np
import time
from PyFingerprint.fingerprint import  get_fingerprints
def des_gen2(data):
    calc = Calculator(descriptors, ignore_3D=True)
    df = data['smile'].tolist()
    mols = [Chem.MolFromSmiles(smi) for smi in df]
    df2 = calc.pandas(mols,nproc=1)
    df2.columns=calc.descriptors
    rest = df2._get_numeric_data()
    rest.index=data['name']
    return rest
data=pd.read_csv('../Descriptor result/new.csv')
a=des_gen2(data)
a.to_csv('../Descriptor result/miaoshufu.csv')